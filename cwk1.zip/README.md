# Coursework 1

Put all of the files for Coursework 1 in this directory.

If the coursework specification gives you instructions for how to organise
your files, please follow those instructions precisely.
